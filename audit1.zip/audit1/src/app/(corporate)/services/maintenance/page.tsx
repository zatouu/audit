'use client'

import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { Wrench, CheckCircle, Phone, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function MaintenanceServicePage() {
  return (
    <main>
      <Header />
      <section className="bg-gradient-to-br from-stone-50 via-white to-stone-50 dark:from-black dark:via-black dark:to-black page-content pt-28 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 text-stone-900 dark:text-white">Maintenance & Support</h1>
            <p className="text-stone-600 dark:text-stone-300 max-w-3xl mx-auto">
              Maintenez vos systèmes en parfait état: maintenance préventive, support 24h/7j, mise à jour firmware et audit complet.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-stone-100 dark:border-slate-800 p-6">
              <h2 className="text-xl font-semibold mb-4 flex items-center">
                <Wrench className="h-5 w-5 text-orange-600 mr-2" />
                Prestations
              </h2>
              <ul className="space-y-2 text-stone-700 dark:text-stone-300 text-sm">
                {[
                  'Maintenance préventive programmée',
                  'Support technique réactif 24h/7j',
                  'Diagnostic & audit système complet',
                  'Mise à jour firmware et logiciels',
                  'Nettoyage et vérification matériel',
                ].map((f) => (
                  <li key={f} className="flex items-start">
                    <CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-stone-100 dark:border-slate-800 p-6">
              <h2 className="text-xl font-semibold mb-4">Contact</h2>
              <div className="flex flex-wrap gap-3">
                <a
                  href={`https://wa.me/221774133440?text=${encodeURIComponent('Bonjour, je souhaite souscrire à un contrat de maintenance.')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-gradient-to-r from-emerald-300 to-emerald-300 hover:from-emerald-400 hover:to-emerald-400 text-white px-4 py-3 rounded-lg font-semibold transition-all inline-flex items-center"
                >
                  <svg className="h-4 w-4 mr-2" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347" /></svg>
                  WhatsApp
                </a>
                <Link href="/contact" className="bg-gradient-to-r from-emerald-300 to-emerald-300 hover:from-emerald-400 hover:to-emerald-400 text-white px-4 py-3 rounded-lg font-semibold transition-all inline-flex items-center">
                  Nous contacter
                  <ArrowRight className="h-4 w-4 ml-2" />
                </Link>
                <a href="tel:+221774133440" className="border-2 border-stone-300 dark:border-stone-500 text-stone-700 dark:text-stone-200 px-4 py-3 rounded-lg font-semibold hover:bg-stone-50 dark:hover:bg-slate-900 inline-flex items-center">
                  <Phone className="h-4 w-4 mr-2" />
                  +221 77 413 34 40
                </a>
              </div>
            </div>
          </div>

          {/* Bloc descriptif enrichi */}
          <div className="mt-12 grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-stone-100 dark:border-slate-800 p-6">
              <h3 className="text-xl font-semibold mb-3 text-stone-900 dark:text-white">Pourquoi la maintenance</h3>
              <p className="text-stone-700 dark:text-stone-300 mb-3">
                Sans maintenance, les systèmes se dégradent silencieusement: <strong>images manquantes</strong>,
                <strong> alertes désactivées</strong>, <strong>mises à jour absentes</strong>. Un plan préventif assure
                fiabilité et longévité.
              </p>
              <ul className="space-y-2 text-stone-700 dark:text-stone-300 text-sm">
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />Réduction des pannes critiques</li>
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />Performance et sécurité maximisées</li>
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />Coûts maîtrisés, visibilité budgétaire</li>
              </ul>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-stone-100 dark:border-slate-800 p-6">
              <h3 className="text-xl font-semibold mb-3 text-stone-900 dark:text-white">Ce que nous faisons</h3>
              <ul className="space-y-2 text-stone-700 dark:text-stone-300 text-sm">
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />Visites planifiées et rapports détaillés</li>
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />Mises à jour firmware/logiciels</li>
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />Nettoyage capteurs, vérif. enregistrement</li>
              </ul>
            </div>

            <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-lg border border-stone-100 dark:border-slate-800 p-6">
              <h3 className="text-xl font-semibold mb-3 text-stone-900 dark:text-white">Apport IT Vision</h3>
              <p className="text-stone-700 dark:text-stone-300 mb-3">
                Un contrat clair, <strong>indicateurs</strong> de disponibilité, tableau de bord et <strong>support 24/7</strong>.
              </p>
              <ul className="space-y-2 text-stone-700 dark:text-stone-300 text-sm">
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />SLA adaptés à vos enjeux</li>
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />Hotline et interventions programmées</li>
                <li className="flex items-start"><CheckCircle className="h-4 w-4 text-emerald-600 mr-2 mt-0.5" />Historique centralisé, conformité</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      <Footer />
    </main>
  )
}
