'use client'
import { useState, useEffect, useCallback } from 'react'
import { useParams } from 'next/navigation'
import {
  FileText, Package, Loader2, AlertCircle,
  MessageSquare, Send, CheckCircle, Ban,
  ArrowRight, Tag, MapPin, Building2, Clock,
  Paperclip, Eye, ExternalLink, Download, X
} from 'lucide-react'
import { BTN_GHOST, CARD, fmtDate, fmtNum, quoteStatus, quoteClientResponseShort, StatusBadge, DetailHeader } from '@/components/portal-ui'
import QuoteResponseModal, { type QuoteModalTab } from '@/components/portal/QuoteResponseModal'

export default function QuoteDetailPage() {
  const { id } = useParams() as { id: string }
  const [q, setQ] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [preview, setPreview] = useState<{ name: string; url: string } | null>(null)
  const [modalTab, setModalTab] = useState<QuoteModalTab | null>(null)
  const [canRespondRole, setCanRespondRole] = useState(true)

  useEffect(() => {
    fetch(`/api/client-enterprise/quotes/${id}`)
      .then(async r => {
        if (r.status === 403) throw new Error((await r.json().catch(() => null))?.error || 'Accès refusé.')
        if (!r.ok) throw new Error('Impossible de charger le devis.')
        return r.json()
      })
      .then(d => {
        setQ(d.quote)
        setLoading(false)
        if (new URLSearchParams(window.location.search).get('repondre') === '1') setModalTab('action')
      })
      .catch((e: Error) => { setError(e.message); setLoading(false) })
  }, [id])

  // Le rôle du membre peut interdire la réponse (capability 'quotes:respond' côté API)
  useEffect(() => {
    fetch('/api/client-enterprise/me')
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (Array.isArray(d?.capabilities)) setCanRespondRole(d.capabilities.includes('quotes:respond')) })
      .catch(() => {})
  }, [])

  const handleAction = useCallback((updated: any) => {
    setQ((prev: any) => ({
      ...prev,
      ...updated,
      clientComments: Array.isArray(updated?.clientComments)
        ? [...updated.clientComments].sort((a: any, b: any) => new Date(a?.createdAt || 0).getTime() - new Date(b?.createdAt || 0).getTime())
        : prev?.clientComments,
    }))
  }, [])

  if (loading) return <div className="p-6 flex items-center justify-center h-64"><Loader2 className="w-6 h-6 animate-spin text-stone-300" /></div>
  if (error) return <div className="p-4 sm:p-6"><div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-center"><AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-2" /><p className="text-sm text-red-700">{error}</p></div></div>
  if (!q) return null

  const canRespond = q.status === 'sent' && (!q.clientResponse || q.clientResponse === 'pending')
  const responseIcon = q.clientResponse === 'accepted' ? CheckCircle : q.clientResponse === 'rejected' ? Ban : q.clientResponse === 'counter_proposed' ? ArrowRight : undefined

  return (
    <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-6 lg:py-10 space-y-6">
      {/* Header */}
      <DetailHeader
        back={{ href: '/portail-entreprise/documents', label: 'Documents' }}
        icon={FileText}
        title={q.title || 'Devis'}
        badges={
          <>
            <StatusBadge status={q.status} map={quoteStatus} fallback="draft" />
            {q.clientResponse && (
              <StatusBadge status={q.clientResponse} map={quoteClientResponseShort} />
            )}
          </>
        }
        meta={<>{q.numero ? <span className="font-mono">N° {q.numero}</span> : ''} · {fmtDate(q.date)}</>}
      >
        <div className="mt-4 flex flex-wrap gap-2">
          <a href={`/api/client-enterprise/quotes/${id}/pdf`} className={BTN_GHOST}>
            <Download className="w-4 h-4" /> Télécharger le PDF
          </a>
          <a href={`/api/client-enterprise/quotes/${id}/pdf?inline=1`} target="_blank" rel="noopener noreferrer" className={BTN_GHOST}>
            <Eye className="w-4 h-4" /> Aperçu
          </a>
          <button type="button" onClick={() => setModalTab('comments')} className={BTN_GHOST}>
            <MessageSquare className="w-4 h-4" /> Poser une question
          </button>
        </div>
      </DetailHeader>

      {/* Réponse client */}
      {canRespond && (
        <div className="rounded-2xl border border-amber-200 bg-amber-50/60 p-4 flex flex-col sm:flex-row sm:items-center gap-3 sm:justify-between">
          <div className="flex items-center gap-2 text-sm text-amber-800">
            <Clock className="w-4 h-4 flex-shrink-0" />
            <span>
              Ce devis attend votre réponse
              {!canRespondRole && " : il faut le droit « Accepter ou refuser les devis », qu'un administrateur de votre espace peut vous accorder. Vous pouvez poser une question en attendant."}
            </span>
          </div>
          {canRespondRole && (
            <button type="button" onClick={() => setModalTab('action')}
              className="inline-flex items-center justify-center gap-1.5 rounded-full bg-emerald-800 text-white px-4 py-2 text-xs font-semibold hover:bg-emerald-900 transition-colors flex-shrink-0">
              <Send className="w-3 h-3" /> Répondre
            </button>
          )}
        </div>
      )}

      {/* Infos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        <div className={`${CARD} p-4`}>
          <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-[0.12em] mb-1.5 flex items-center gap-1"><Building2 className="w-3 h-3" /> Client</p>
          <p className="text-sm font-medium text-stone-900">{q.client?.name || '—'}</p>
          {q.client?.email && <p className="text-xs text-stone-400 mt-0.5">{q.client.email}</p>}
          {q.client?.phone && <p className="text-xs text-stone-400">{q.client.phone}</p>}
        </div>
        <div className={`${CARD} p-4`}>
          <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-[0.12em] mb-1.5 flex items-center gap-1"><MapPin className="w-3 h-3" /> Livraison</p>
          <p className="text-sm font-medium text-stone-900">{q.pointExpedition || '—'}</p>
          {q.dateLivraison && <p className="text-xs text-stone-400 mt-0.5">Date prévue : {q.dateLivraison}</p>}
        </div>
        <div className={`${CARD} p-4`}>
          <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-[0.12em] mb-1.5 flex items-center gap-1"><Tag className="w-3 h-3" /> Conditions</p>
          <p className="text-sm font-medium text-stone-900">{q.conditions || '—'}</p>
        </div>
      </div>

      {/* Produits */}
      <div className={`${CARD} overflow-hidden`}>
        <div className="px-4 sm:px-5 py-3.5 border-b border-stone-100 flex items-center gap-2">
          <Package className="w-4 h-4 text-emerald-700" />
          <span className="text-sm font-semibold text-stone-900">Prestations & fournitures</span>
          <span className="text-xs text-stone-400 ml-auto tabular-nums">{q.products?.length || 0} ligne(s)</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-stone-100 bg-stone-50/60">
                <th className="text-left px-4 sm:px-5 py-2.5 text-[11px] font-semibold text-stone-400 uppercase tracking-wide">Description</th>
                <th className="text-right px-4 sm:px-5 py-2.5 text-[11px] font-semibold text-stone-400 uppercase tracking-wide">Qté</th>
                <th className="text-right px-4 sm:px-5 py-2.5 text-[11px] font-semibold text-stone-400 uppercase tracking-wide">Prix unit.</th>
                <th className="text-right px-4 sm:px-5 py-2.5 text-[11px] font-semibold text-stone-400 uppercase tracking-wide">Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {(q.products || []).map((p: any, i: number) => (
                <tr key={i}>
                  <td className="px-4 sm:px-5 py-3 text-stone-900 font-medium">{p.description}</td>
                  <td className="px-4 sm:px-5 py-3 text-right text-stone-500 tabular-nums">{p.quantity}</td>
                  <td className="px-4 sm:px-5 py-3 text-right text-stone-500 tabular-nums">{fmtNum(p.unitPrice)} F</td>
                  <td className="px-4 sm:px-5 py-3 text-right font-semibold text-stone-900 tabular-nums">{fmtNum(p.total)} F</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Totaux */}
        <div className="border-t border-stone-100 px-4 sm:px-5 py-4 space-y-1.5 bg-stone-50/60">
          <div className="flex justify-between text-sm text-stone-500">
            <span>Sous-total</span>
            <span className="text-stone-700 tabular-nums">{fmtNum(q.subtotal)} FCFA</span>
          </div>
          {q.brsAmount > 0 && (
            <div className="flex justify-between text-sm text-stone-500">
              <span>BRS (-5%)</span>
              <span className="text-red-600 tabular-nums">-{fmtNum(q.brsAmount)} FCFA</span>
            </div>
          )}
          {q.taxAmount > 0 && (
            <div className="flex justify-between text-sm text-stone-500">
              <span>TVA</span>
              <span className="text-stone-700 tabular-nums">{fmtNum(q.taxAmount)} FCFA</span>
            </div>
          )}
          {q.other > 0 && (
            <div className="flex justify-between text-sm text-stone-500">
              <span>Autres</span>
              <span className="text-stone-700 tabular-nums">{fmtNum(q.other)} FCFA</span>
            </div>
          )}
          <div className="flex justify-between pt-2 border-t border-stone-200">
            <span className="text-sm font-bold text-stone-900">TOTAL</span>
            <span className="text-lg font-bold text-emerald-800 tabular-nums">{fmtNum(q.total)} FCFA</span>
          </div>
        </div>
      </div>

      {/* Notes */}
      {q.notes && (
        <div className={`${CARD} p-5`}>
          <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-[0.12em] mb-2">Notes</p>
          <p className="text-sm text-stone-600 whitespace-pre-line">{q.notes}</p>
        </div>
      )}

      {/* Pièces jointes */}
      {(q.attachments || []).length > 0 && (
        <div className={`${CARD} p-5`}>
          <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-[0.12em] mb-3 flex items-center gap-1.5"><Paperclip className="w-3.5 h-3.5" /> Pièces jointes ({q.attachments.length})</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {q.attachments.map((a: any, i: number) => {
              const isPdf = (a.url || '').split('?')[0].toLowerCase().endsWith('.pdf')
              return (
                <div key={i} className="flex items-center gap-3 rounded-xl border border-stone-100 bg-stone-50/50 p-3">
                  <div className="w-9 h-9 rounded-lg bg-white border border-stone-200 flex items-center justify-center flex-shrink-0"><FileText className="w-4 h-4 text-emerald-700" /></div>
                  <div className="flex-1 min-w-0">
                    <button onClick={() => isPdf ? setPreview(a) : window.open(a.url, '_blank')} className="text-xs font-medium text-stone-900 hover:text-emerald-800 truncate block text-left w-full">{a.name}</button>
                    <div className="flex items-center gap-2.5 mt-1">
                      {isPdf && <button onClick={() => setPreview(a)} className="inline-flex items-center gap-1 text-[10px] font-medium text-emerald-800 hover:text-emerald-950"><Eye className="w-3 h-3" />Aperçu</button>}
                      <a href={a.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-[10px] font-medium text-stone-400 hover:text-stone-700"><ExternalLink className="w-3 h-3" />Ouvrir</a>
                      <a href={a.url} download className="inline-flex items-center gap-1 text-[10px] font-medium text-stone-400 hover:text-stone-700"><Download className="w-3 h-3" /></a>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Historique réponse */}
      {q.clientResponse && q.clientResponse !== 'pending' && (
        <div className={`${CARD} p-5`}>
          <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-[0.12em] mb-3">Votre réponse</p>
          <div className="flex items-center gap-2 flex-wrap">
            <StatusBadge status={q.clientResponse} map={quoteClientResponseShort} icon={responseIcon} />
            <span className="text-xs text-stone-400">{fmtDate(q.clientRespondedAt)}</span>
          </div>
          {q.clientCounterAmount && (
            <p className="text-sm text-emerald-800 font-semibold tabular-nums mt-1">Contre-proposition : {fmtNum(q.clientCounterAmount)} FCFA</p>
          )}
          {q.clientSignature && (
            <div className="mt-4 pt-4 border-t border-stone-100">
              <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-[0.12em] mb-2">Signature électronique</p>
              <div className="flex items-center gap-4 flex-wrap">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={q.clientSignature.signature} alt="Signature" className="h-14 rounded-lg bg-stone-50 border border-stone-200 object-contain px-2" />
                <div>
                  <p className="text-sm font-medium text-stone-900">{q.clientSignature.name}</p>
                  <p className="text-xs text-stone-400">Signé le {fmtDate(q.clientSignature.signedAt)}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Commentaires */}
      {(q.clientComments || []).length > 0 && (
        <div className={`${CARD} p-5`}>
          <p className="text-[11px] font-semibold text-stone-400 uppercase tracking-[0.12em] mb-3 flex items-center gap-1.5"><MessageSquare className="w-3.5 h-3.5" /> Commentaires ({q.clientComments.length})</p>
          <div className="space-y-3">
            {(q.clientComments || []).map((c: any, i: number) => (
              <div key={i} className={`rounded-xl p-3 ${c.authorRole === 'CLIENT' ? 'bg-emerald-50 border border-emerald-100' : 'bg-stone-50 border border-stone-100'}`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className={`text-[10px] font-bold ${c.authorRole === 'CLIENT' ? 'text-emerald-700' : 'text-stone-500'}`}>{c.authorRole === 'CLIENT' ? 'Vous' : 'IT Vision'}</span>
                  <span className="text-[10px] text-stone-400">{fmtDate(c.createdAt)}</span>
                </div>
                <p className="text-sm text-stone-700">{c.message}</p>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Preview modal */}
      {modalTab && (
        <QuoteResponseModal
          quote={q}
          initialTab={modalTab}
          canRespond={canRespondRole}
          onAction={handleAction}
          onClose={() => setModalTab(null)}
        />
      )}
      {preview && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-3 sm:p-6" onClick={() => setPreview(null)}>
          <div className="bg-white rounded-2xl w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="flex items-center gap-3 px-4 py-3 border-b border-stone-200">
              <FileText className="w-5 h-5 text-emerald-700 flex-shrink-0" />
              <p className="flex-1 min-w-0 text-sm font-semibold text-stone-900 truncate">{preview.name}</p>
              <a href={preview.url} target="_blank" rel="noopener noreferrer" className="p-2 text-stone-500 hover:bg-stone-100 rounded-lg" title="Ouvrir dans un nouvel onglet"><ExternalLink className="w-4 h-4" /></a>
              <a href={preview.url} download className="p-2 text-stone-500 hover:bg-stone-100 rounded-lg" title="Télécharger"><Download className="w-4 h-4" /></a>
              <button onClick={() => setPreview(null)} className="p-2 text-stone-500 hover:bg-stone-100 rounded-lg" title="Fermer"><X className="w-4 h-4" /></button>
            </div>
            <div className="flex-1 min-h-0 bg-stone-100">
              <iframe src={`${preview.url}#toolbar=1&view=FitH`} className="w-full h-full min-h-[70vh]" title={preview.name} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
