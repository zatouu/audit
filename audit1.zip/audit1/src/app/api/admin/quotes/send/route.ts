import { NextRequest, NextResponse } from 'next/server'
import { connectMongoose } from '@/lib/mongoose'
import { requireAdminApi } from '@/lib/api-auth'
import AdminQuote from '@/lib/models/AdminQuote'
import { generateITVisionQuotePdf } from '@/lib/pdf'
import { emailService } from '@/lib/email-service'
import { getClientEmailRecipients } from '@/lib/client-contacts'
import { notifyQuoteWorkflowEvent } from '@/lib/quote-notifications'
import { getBrandFromHost } from '@/lib/branding'
import fs from 'fs'
import path from 'path'

// Helper to load image
const loadImage = (relativePath: string) : string | undefined => {
  try {
    const fullPath = path.join(process.cwd(), relativePath)
    if (fs.existsSync(fullPath)) {
      return fs.readFileSync(fullPath).toString('base64')
    }
  } catch (e) {
    console.error(`Failed to load image ${relativePath}`, e)
  }
  return undefined
}

export async function POST(request: NextRequest) {
  try {
    const brand = getBrandFromHost(request.nextUrl.host)
    const auth = await requireAdminApi(request)
    if (!auth.ok) return NextResponse.json({ error: auth.error }, { status: auth.status })

    const body = await request.json().catch(() => null) as any
    const id = String(body?.id || body?._id || '').trim()
    const to = String(body?.to || '').trim()
    const recipients = Array.isArray(body?.recipients)
      ? body.recipients.filter((r: string) => r && r.includes('@'))
      : []

    if (!id) return NextResponse.json({ error: 'ID requis' }, { status: 400 })

    await connectMongoose()

    const quote = await AdminQuote.findById(id).lean() as any
    if (!quote) return NextResponse.json({ error: 'Devis introuvable' }, { status: 404 })
    if (quote.status === 'superseded') {
      return NextResponse.json({ error: 'Ce devis a été remplacé par une nouvelle version : envoyez la dernière version' }, { status: 409 })
    }

    // Résoudre les emails contacts du client
    let recipient = to
    if (recipients.length > 0) {
      recipient = recipients.join(', ')
    } else if (!recipient && quote.clientCompanyId) {
      recipient = await getClientEmailRecipients(String(quote.clientCompanyId), String(quote?.client?.email || ''))
    }
    if (!recipient) {
      recipient = String(quote?.client?.email || '').trim()
    }
    if (!recipient) return NextResponse.json({ error: 'Email destinataire manquant' }, { status: 400 })

    const pdfArrayBuffer = generateITVisionQuotePdf({
      numero: String(quote.numero || ''),
      date: quote.date ? new Date(quote.date).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
      client: {
        name: String(quote.client?.name || ''),
        address: String(quote.client?.address || ''),
        phone: String(quote.client?.phone || ''),
        email: String(quote.client?.email || ''),
        rcn: quote.client?.rcn,
        ninea: quote.client?.ninea
      },
      products: Array.isArray(quote.products)
        ? quote.products.map((p: any) => ({
            description: String(p.description || ''),
            quantity: Number(p.quantity || 0),
            unitPrice: Number(p.unitPrice || 0),
            taxable: Boolean(p.taxable),
            total: Number(p.total || 0)
          }))
        : [],
      subtotal: Number(quote.subtotal || 0),
      brsAmount: Number(quote.brsAmount || 0),
      taxAmount: Number(quote.taxAmount || 0),
      other: Number(quote.other || 0),
      total: Number(quote.total || 0),
      notes: quote.notes,
      bonCommande: quote.bonCommande,
      dateLivraison: quote.dateLivraison,
      images: {
        logo: loadImage('public/images/logo-it-vision.png'),
        stamp: loadImage('public/images/cachetitv.png')
      }
    })

    const pdfBytes = Buffer.from(new Uint8Array(pdfArrayBuffer))

    const siteUrl = brand.url

    const delivery = await emailService.sendEmailDetailed({
      to: recipient,
      fromName: brand.name,
      brand,
      subject: `Devis ${quote.numero} - ${brand.name}`,
      html: `
        <p>Bonjour,</p>
        <p>Veuillez trouver ci-joint votre devis <strong>${quote.numero}</strong>.</p>
        <p>Merci de votre confiance.</p>
        <p><a href="${siteUrl}">${siteUrl}</a></p>
      `,
      attachments: [
        {
          filename: `Devis-${quote.numero}.pdf`,
          content: pdfBytes,
          contentType: 'application/pdf'
        }
      ]
    })
    const ok = delivery.ok

    if (ok) {
      await AdminQuote.updateOne(
        { _id: id },
        {
          $set: {
            status: quote.status === 'draft' ? 'sent' : quote.status,
            sentAt: new Date()
          }
        }
      )

      await notifyQuoteWorkflowEvent({
        eventType: 'quote_sent',
        quote,
        actorName: auth.user.name || auth.user.email || 'Administrateur',
        clientUserId: quote.clientUserId ? String(quote.clientUserId) : undefined,
        clientCompanyId: quote.clientCompanyId ? String(quote.clientCompanyId) : undefined
      })
    }

    // delivery 'simulated' = publié au portail mais aucun email parti (SMTP absent) ; copyTo = copie de contrôle ITV
    return NextResponse.json({ success: ok, delivery: delivery.status, to: recipient, copyTo: delivery.bcc })
  } catch (error) {
    console.error('Erreur envoi devis:', error)
    return NextResponse.json({ error: 'Erreur lors de l\'envoi du devis' }, { status: 500 })
  }
}
