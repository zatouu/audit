import { NextRequest, NextResponse } from 'next/server'
import { requireDomainAccess, requireCompanyCapability, companyScope } from '@/lib/domain-access'
import { connectDB } from '@/lib/db'
import mongoose from 'mongoose'
import Intervention from '@/lib/models/Intervention'
import MaintenanceContract from '@/lib/models/MaintenanceContract'
import { addNotification } from '@/lib/notifications-memory'
import { logAuditEvent } from '@/lib/audit'

export async function POST(request: NextRequest) {
  const result = await requireDomainAccess(request, 'corporate')
  if (!result.ok) return result.response
  const { access } = result

  const denied = requireCompanyCapability(access, 'maintenance:request')
  if (denied) return denied

  await connectDB()
  const userId = new mongoose.Types.ObjectId(access.userId)
  const companyId = access.profiles.companyClientId
  const body = await request.json()

  const { title, description, typeIntervention, priority, site, preferredDate } = body
  if (!title || !description || !typeIntervention) {
    return NextResponse.json({ error: 'Titre, description et type requis' }, { status: 400 })
  }

  const validTypes = ['maintenance', 'installation', 'repair', 'inspection', 'emergency']
  if (!validTypes.includes(typeIntervention)) {
    return NextResponse.json({ error: 'Type intervention invalide' }, { status: 400 })
  }

  // Auto-détection contrat actif
  const now = new Date()
  const activeContract = await MaintenanceContract.findOne({
    ...companyScope({ userId, companyId }),
    status: 'active',
    startDate: { $lte: now },
    endDate: { $gte: now }
  }).lean() as any

  let maintenanceContractId: mongoose.Types.ObjectId | undefined
  let isCoveredByContract = false
  let overageAlert = false

  if (activeContract) {
    const used = activeContract.coverage?.interventionsUsed || 0
    const included = activeContract.coverage?.interventionsIncluded || 0
    if (included > 0 && used >= included) {
      isCoveredByContract = false
      overageAlert = true
    } else {
      maintenanceContractId = activeContract._id
      isCoveredByContract = true
    }
  }

  const intervention = await Intervention.create({
    title,
    description,
    clientId: userId,
    typeIntervention,
    service: typeIntervention,
    priority: priority || 'medium',
    status: 'pending',
    site: site || undefined,
    date: preferredDate ? new Date(preferredDate) : undefined,
    maintenanceContractId,
    isCoveredByContract
  })

  // Audit trail — la demande d'intervention est un événement traçable
  logAuditEvent({
    entityType: 'Intervention',
    entityId: intervention._id,
    action: 'created',
    newState: { status: intervention.status, typeIntervention, priority: intervention.priority },
    userId: access.userId,
    userRole: 'CLIENT',
    clientCompanyId: companyId,
    metadata: { coveredByContract: isCoveredByContract }
  }).catch(e => console.error('[Audit] intervention request:', e))

  // Notification admin
  addNotification({
    userId: 'admin',
    type: 'info',
    title: 'Nouvelle demande intervention client',
    message: `${access.email || 'Un client'} a demandé une intervention : ${title}`,
    actionUrl: `/admin/maintenance/interventions/${intervention._id}`,
    metadata: { interventionId: String(intervention._id), clientId: String(userId) }
  })

  return NextResponse.json({
    success: true,
    intervention,
    ...(overageAlert && { warning: 'Plafond interventions du contrat atteint. Intervention hors contrat.' })
  }, { status: 201 })
}
