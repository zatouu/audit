import { NextRequest, NextResponse } from 'next/server'
import { requireDomainAccess, companyScope, canCompany } from '@/lib/domain-access'
import { connectDB } from '@/lib/db'
import mongoose from 'mongoose'
import MaintenanceContract from '@/lib/models/MaintenanceContract'
import Intervention from '@/lib/models/Intervention'
import Project from '@/lib/models/Project'
import { clientProjectFilter } from '@/lib/portal/project-view'
import AdminQuote from '@/lib/models/AdminQuote'
import AdminInvoice from '@/lib/models/AdminInvoice'
import Ticket from '@/lib/models/Ticket'
import Client from '@/lib/models/Client'

export async function GET(request: NextRequest) {
  const result = await requireDomainAccess(request, 'corporate')
  if (!result.ok) return result.response
  const { access } = result

  await connectDB()
  const userId = new mongoose.Types.ObjectId(access.userId)
  const companyId = access.profiles.companyClientId
  // Sans finance:view : ni factures, ni montants ; les devis restent visibles pour qui doit y répondre
  const canFinance = access.isAdmin || canCompany(access, 'finance:view')
  const canQuotes = canFinance || canCompany(access, 'quotes:respond')
  const contractFields = 'contractNumber name type status startDate endDate coverage stats' + (canFinance ? ' annualPrice' : '')
  const projectFields = 'name status startDate endDate progress currentPhase milestones serviceType' + (canFinance ? ' value' : '')

  const [
    clientDoc,
    contracts,
    recentInterventions,
    activeProjects,
    pendingQuotes,
    unpaidInvoices,
    openTickets
  ] = await Promise.all([
    (companyId ? Client.findById(companyId).select('name company city country contracts').lean() : Promise.resolve(null)),

    MaintenanceContract.find({ ...companyScope({ userId, companyId }), status: { $in: ['active', 'draft'] } })
      .sort({ endDate: 1 })
      .limit(5)
      .select(contractFields)
      .lean(),

    Intervention.find(companyScope({ userId, companyId }))
      .sort({ date: -1, createdAt: -1 })
      .limit(5)
      .select('interventionNumber title typeIntervention priority status date service site technicienId')
      .lean(),

    Project.find(clientProjectFilter(companyScope({ userId, companyId }), {
      status: { $in: ['in_progress', 'testing', 'approved', 'quoted'] }
    }))
      .sort({ updatedAt: -1 })
      .limit(5)
      .select(projectFields)
      .lean(),

    !canQuotes ? [] : AdminQuote.find({
      ...(companyId ? { $or: [{ clientUserId: userId }, { clientCompanyId: companyId }] } : { clientUserId: userId }),
      status: 'sent'
    })
      .sort({ date: -1 })
      .limit(5)
      .select('numero title date status total client')
      .lean(),

    !canFinance ? [] : AdminInvoice.find({
      ...(companyId ? { $or: [{ clientUserId: userId }, { clientCompanyId: companyId }] } : { clientUserId: userId }),
      status: { $in: ['sent', 'overdue', 'partial'] }
    })
      .sort({ dueDate: 1 })
      .limit(5)
      .select('numero date dueDate status total client')
      .lean(),

    Ticket.find({ ...companyScope({ userId, companyId }), status: { $in: ['open', 'in_progress', 'waiting_client', 'waiting'] } })
      .sort({ createdAt: -1 })
      .limit(5)
      .select('title category priority status createdAt sla')
      .lean()
  ])

  // Agrégations KPI
  const [
    totalContracts,
    totalInterventions,
    totalProjects,
    totalInvoicesDue,
    totalOpenTickets,
    interventionsThisMonth
  ] = await Promise.all([
    MaintenanceContract.countDocuments({ ...companyScope({ userId, companyId }), status: 'active' }),
    Intervention.countDocuments(companyScope({ userId, companyId })),
    Project.countDocuments(clientProjectFilter(companyScope({ userId, companyId }))),
    !canFinance ? [] : AdminInvoice.aggregate([
      { $match: { ...(companyId ? { $or: [{ clientUserId: userId }, { clientCompanyId: companyId }] } : { clientUserId: userId }), status: { $in: ['sent', 'overdue', 'partial'] } } },
      { $group: { _id: null, total: { $sum: { $subtract: ['$total', { $add: [{ $ifNull: ['$amountPaid', 0] }, { $ifNull: ['$creditedAmount', 0] }] }] } } } }
    ]),
    Ticket.countDocuments({ ...companyScope({ userId, companyId }), status: { $in: ['open', 'in_progress', 'waiting_client', 'waiting'] } }),
    Intervention.countDocuments({
      ...companyScope({ userId, companyId }),
      date: { $gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) }
    })
  ])

  const amountDue = canFinance ? (totalInvoicesDue[0]?.total ?? 0) : null

  // Prochaine intervention planifiée
  const nextIntervention = await Intervention.findOne({
    ...companyScope({ userId, companyId }),
    date: { $gte: new Date() },
    status: { $nin: ['completed', 'cancelled'] }
  })
    .sort({ date: 1 })
    .select('title date service site')
    .lean()

  // Contrat proche expiration (60j)
  const expiringContract = contracts.find((c: any) => {
    const days = Math.floor((new Date(c.endDate).getTime() - Date.now()) / 86400000)
    return days > 0 && days <= 60
  })

  return NextResponse.json({
    company: clientDoc,
    kpis: {
      activeContracts: totalContracts,
      totalInterventions,
      totalProjects,
      amountDue,
      openTickets: totalOpenTickets,
      interventionsThisMonth
    },
    alerts: {
      expiringContract: expiringContract ? {
        id: String((expiringContract as any)._id),
        name: (expiringContract as any).name,
        endDate: (expiringContract as any).endDate,
        daysLeft: Math.floor((new Date((expiringContract as any).endDate).getTime() - Date.now()) / 86400000)
      } : null,
      overdueInvoices: (unpaidInvoices as any[]).filter((i: any) => i.status === 'overdue').length,
      criticalTickets: openTickets.filter((t: any) => t.priority === 'urgent').length,
      nextIntervention: nextIntervention ? {
        title: (nextIntervention as any).title,
        date: (nextIntervention as any).date,
        site: (nextIntervention as any).site
      } : null
    },
    recent: {
      contracts,
      interventions: recentInterventions,
      projects: activeProjects,
      quotes: pendingQuotes,
      invoices: unpaidInvoices,
      tickets: openTickets
    }
  })
}
