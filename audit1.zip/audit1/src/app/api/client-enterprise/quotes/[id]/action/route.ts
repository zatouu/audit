import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import mongoose from 'mongoose'
import AdminQuote from '@/lib/models/AdminQuote'
import { CLIENT_VISIBLE_QUOTE } from '@/lib/client-documents'
import emailService from '@/lib/email-service'
import { notifyQuoteWorkflowEvent } from '@/lib/quote-notifications'
import { getBrandFromHost, BrandConfig } from '@/lib/branding'
import { applyRateLimit, quoteActionRateLimiter } from '@/lib/rate-limiter'
import { logAuditEvent } from '@/lib/audit'
import { requireDomainAccess, requireCompanyCapability } from '@/lib/domain-access'
import { escapeHtml as esc } from '@/lib/html-escape'
import { syncProjectWithQuoteDecision } from '@/lib/finance/billing'

function fmt(v: number) { return Math.round(v).toLocaleString('fr-FR') }

function normalizeQuoteForResponse(quote: any) {
  if (!quote) return quote
  return {
    ...quote,
    products: Array.isArray(quote.products) ? quote.products : [],
    clientComments: Array.isArray(quote.clientComments)
      ? [...quote.clientComments].sort((a: any, b: any) => {
          const at = new Date(a?.createdAt || 0).getTime()
          const bt = new Date(b?.createdAt || 0).getTime()
          return at - bt
        })
      : []
  }
}

function buildAdminNotificationHtml(quote: any, action: string, message: string, brand: BrandConfig, counterAmount?: number, clientName?: string) {
  const actionLabel = action === 'accepted' ? 'Accepté' : action === 'rejected' ? 'Refusé' : action === 'counter_proposed' ? 'Contre-proposition' : 'Commentaire'
  const color = action === 'accepted' ? '#16a34a' : action === 'rejected' ? '#dc2626' : '#7c3aed'
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    body{font-family:Arial,sans-serif;line-height:1.6;color:#333;margin:0;padding:0}
    .container{max-width:600px;margin:0 auto;padding:20px}
    .header{background:linear-gradient(135deg,#22c55e,#7c3aed);color:white;padding:24px;border-radius:10px 10px 0 0;text-align:center}
    .content{background:#f8f9fa;padding:24px;border-radius:0 0 10px 10px}
    .badge{display:inline-block;padding:6px 16px;border-radius:20px;font-weight:bold;color:white;background:${color}}
    .box{background:white;border-radius:8px;padding:16px;margin:16px 0;border:1px solid #e5e7eb}
    .btn{display:inline-block;background:linear-gradient(135deg,#22c55e,#7c3aed);color:white;padding:12px 24px;text-decoration:none;border-radius:8px;margin:16px 0}
    .footer{text-align:center;font-size:12px;color:#888;margin-top:16px}
  </style></head><body><div class="container">
    <div class="header"><h2>Portail Client — Action sur Devis</h2></div>
    <div class="content">
      <p>Le client <strong>${esc(clientName) || 'Inconnu'}</strong> a effectué une action sur le devis <strong>${esc(quote.numero)}</strong>.</p>
      <div style="text-align:center;margin:16px 0"><span class="badge">${actionLabel}</span></div>
      <div class="box">
        <strong>Devis :</strong> ${esc(quote.numero)} — ${esc(quote.title) || 'Devis'}<br>
        <strong>Montant :</strong> ${fmt(quote.total)} FCFA<br>
        ${counterAmount ? `<strong>Contre-proposition :</strong> ${fmt(counterAmount)} FCFA<br>` : ''}
        <strong>Date :</strong> ${new Date().toLocaleDateString('fr-FR')}
      </div>
      ${message ? `<div class="box"><strong>Message du client :</strong><br><em>${esc(message)}</em></div>` : ''}
      <a href="${brand.url}/admin" class="btn">Voir dans l'admin</a>
    </div>
    <div class="footer">© ${new Date().getFullYear()} ${brand.name}</div>
  </div></body></html>`
}

function buildClientConfirmHtml(quote: any, action: string, clientName: string, brand: BrandConfig) {
  const actionLabel = action === 'accepted' ? 'accepté' : action === 'rejected' ? 'refusé' : action === 'counter_proposed' ? 'transmis (contre-proposition)' : 'reçu'
  const nextStep = action === 'accepted'
    ? 'Notre équipe va préparer la commande et vous contacter sous 24h pour la suite.'
    : action === 'rejected'
    ? 'Nous prenons note. N\'hésitez pas à nous contacter si vous souhaitez réviser les conditions.'
    : 'Notre équipe analysera votre proposition et reviendra vers vous dans les plus brefs délais.'
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><style>
    body{font-family:Arial,sans-serif;line-height:1.6;color:#333;margin:0;padding:0}
    .container{max-width:600px;margin:0 auto;padding:20px}
    .header{background:linear-gradient(135deg,#22c55e,#7c3aed);color:white;padding:24px;border-radius:10px 10px 0 0;text-align:center}
    .content{background:#f8f9fa;padding:24px;border-radius:0 0 10px 10px}
    .box{background:white;border-radius:8px;padding:16px;margin:16px 0;border:1px solid #e5e7eb}
    .btn{display:inline-block;background:linear-gradient(135deg,#22c55e,#7c3aed);color:white;padding:12px 24px;text-decoration:none;border-radius:8px;margin:16px 0}
    .footer{text-align:center;font-size:12px;color:#888;margin-top:16px}
  </style></head><body><div class="container">
    <div class="header"><h2>Confirmation — Devis ${esc(quote.numero)}</h2></div>
    <div class="content">
      <p>Bonjour <strong>${esc(clientName)}</strong>,</p>
      <p>Nous confirmons que votre réponse au devis <strong>${esc(quote.numero)}</strong> a bien été <strong>${actionLabel}</strong>.</p>
      <div class="box">
        <strong>Devis :</strong> ${esc(quote.numero)} — ${esc(quote.title) || 'Devis'}<br>
        <strong>Montant :</strong> ${fmt(quote.total)} FCFA<br>
        <strong>Date :</strong> ${new Date().toLocaleDateString('fr-FR')}
      </div>
      <p>${nextStep}</p>
      <a href="${brand.url}/portail-entreprise/documents" class="btn">Voir mes documents</a>
      <p style="margin-top:16px">📧 ${brand.contactEmail} &nbsp;|&nbsp; 📱 ${brand.whatsapp}</p>
    </div>
    <div class="footer">© ${new Date().getFullYear()} ${brand.name}</div>
  </div></body></html>`
}

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const rateLimit = await applyRateLimit(request, quoteActionRateLimiter)
  if (rateLimit) return rateLimit

  const { id } = await params
  const brand = getBrandFromHost(request.nextUrl.host)
  const accessResult = await requireDomainAccess(request, 'corporate')
  if (!accessResult.ok) return accessResult.response
  const { access } = accessResult

  const body = await request.json().catch(() => ({}))
  const { action, message, counterAmount, signature, signatureName } = body
  const trimmedMessage = typeof message === 'string' ? message.trim().slice(0, 2000) : ''

  // Décider (accepter, refuser, contre-proposer) engage l'entreprise : droit 'quotes:respond' accordé dans l'espace.
  // Commenter reste ouvert à tout membre ayant accès au devis.
  if (action !== 'comment') {
    const denied = requireCompanyCapability(access, 'quotes:respond')
    if (denied) return denied
  }

  await connectDB()
  const userId = new mongoose.Types.ObjectId(access.userId)
  const companyId = new mongoose.Types.ObjectId(access.profiles.companyClientId!)

  const quote = await AdminQuote.findOne({
    _id: id,
    $or: [{ clientUserId: userId }, { clientCompanyId: companyId }],
    ...CLIENT_VISIBLE_QUOTE,
  })

  if (!quote) return NextResponse.json({ error: 'Devis introuvable' }, { status: 404 })

  // Signature électronique : data URL PNG, taille raisonnable
  const sig = typeof signature === 'string' && signature.startsWith('data:image/png;base64,') && signature.length < 600_000
    ? signature
    : null
  const sigName = typeof signatureName === 'string' ? signatureName.trim().slice(0, 120) : ''

  if (!['accepted', 'rejected', 'counter_proposed', 'comment'].includes(action)) {
    return NextResponse.json({ error: 'Action invalide' }, { status: 400 })
  }

  if (action === 'comment' && !trimmedMessage) {
    return NextResponse.json({ error: 'Le commentaire est requis' }, { status: 400 })
  }

  if (action === 'counter_proposed' && (!counterAmount || Number(counterAmount) <= 0)) {
    return NextResponse.json({ error: 'Le montant de contre-proposition est requis' }, { status: 400 })
  }

  // Une décision (accepter / refuser / contre-proposer) n'a de sens que sur un devis envoyé et pas encore tranché
  const isDecision = action !== 'comment'
  if (isDecision && quote.status !== 'sent') {
    return NextResponse.json({
      error: quote.status === 'accepted' ? 'Ce devis a déjà été accepté' : quote.status === 'rejected' ? 'Ce devis a déjà été refusé' : 'Ce devis ne peut pas encore recevoir de réponse'
    }, { status: 409 })
  }

  const now = new Date()

  // Mettre à jour le statut du devis
  const setUpdate: any = { clientRespondedAt: now }
  if (action !== 'comment') {
    setUpdate.clientResponse = action
    if (action === 'accepted') {
      setUpdate.status = 'accepted'
      setUpdate.acceptedAt = now
      if (sig) {
        setUpdate.clientSignature = {
          signature: sig,
          name: sigName || access.email || 'Client',
          signedAt: now,
          ip: request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || '',
          userAgent: (request.headers.get('user-agent') || '').slice(0, 300),
        }
      }
    } else if (action === 'rejected') {
      setUpdate.status = 'rejected'
      setUpdate.rejectedAt = now
    } else if (action === 'counter_proposed') {
      setUpdate.clientCounterAmount = Number(counterAmount)
    }
  }

  const pushUpdate = trimmedMessage
    ? {
        clientComments: {
          authorId: userId,
          authorRole: 'CLIENT',
          message: trimmedMessage,
          createdAt: now,
          readByOther: false
        }
      }
    : undefined

  if (trimmedMessage) {
    setUpdate.clientRespondedAt = now
  }

  const mongoUpdate: any = { $set: setUpdate }
  if (pushUpdate) {
    mongoUpdate.$push = pushUpdate
  }

  // Condition sur le statut : deux clics simultanés (accepter puis refuser) ne peuvent pas tous deux passer
  const applied = await AdminQuote.updateOne(
    isDecision ? { _id: quote._id, status: 'sent' } : { _id: quote._id },
    mongoUpdate
  )
  if (isDecision && applied.modifiedCount === 0) {
    return NextResponse.json({ error: 'Le devis a été modifié entre-temps, rechargez la page' }, { status: 409 })
  }

  const updatedQuote = await AdminQuote.findById(quote._id).lean()
  const normalizedQuote = normalizeQuoteForResponse(updatedQuote)

  if (action === 'accepted' || action === 'rejected') {
    await syncProjectWithQuoteDecision(quote, action, access.email || 'Client').catch((err) =>
      console.error('Synchro projet après décision devis:', err)
    )
  }

  // Emails
  const clientName = access.email || 'Client'
  const clientEmail = access.email || quote.client?.email
  const adminEmail = process.env.ADMIN_EMAIL || brand.contactEmail

  await Promise.allSettled([
    // Notifier l'admin
    emailService.sendEmail({
      to: adminEmail,
      fromName: brand.name,
      brand,
      subject: `[Portail Client] Devis ${quote.numero} — ${action === 'accepted' ? 'Accepté' : action === 'rejected' ? 'Refusé' : action === 'counter_proposed' ? 'Contre-proposition' : 'Commentaire'} par ${clientName}`,
      html: buildAdminNotificationHtml(quote, action, trimmedMessage, brand, counterAmount, clientName)
    }),
    // Confirmer au client
    clientEmail && action !== 'comment' ? emailService.sendEmail({
      to: clientEmail,
      fromName: brand.name,
      brand,
      subject: `Confirmation — Devis ${quote.numero} ${action === 'accepted' ? 'accepté' : action === 'rejected' ? 'refusé' : 'contre-proposition envoyée'}`,
      html: buildClientConfirmHtml(quote, action, clientName, brand)
    }) : Promise.resolve()
  ])

  const eventType =
    action === 'accepted'
      ? 'client_accepted'
      : action === 'rejected'
      ? 'client_rejected'
      : action === 'counter_proposed'
      ? 'client_counter_proposed'
      : 'client_comment'

  await notifyQuoteWorkflowEvent({
    eventType,
    quote: normalizedQuote || quote,
    actorName: clientName,
    message: trimmedMessage,
    counterAmount: Number(counterAmount || 0) || undefined,
    clientUserId: access.userId,
    clientCompanyId: access.profiles.companyClientId
  })

  void logAuditEvent({
    entityType: 'AdminQuote',
    entityId: quote._id,
    action: `client_${action}`,
    userId: access.userId,
    userRole: 'CLIENT',
    clientCompanyId: access.profiles.companyClientId,
    metadata: { numero: quote.numero, counterAmount: Number(counterAmount || 0) || undefined, hasMessage: !!trimmedMessage, signed: !!sig, companyRole: access.companyRole },
  })

  return NextResponse.json({ success: true, action, quote: normalizedQuote })
}
