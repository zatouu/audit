import { NextRequest, NextResponse } from 'next/server'
import { connectDB } from '@/lib/db'
import mongoose from 'mongoose'
import User from '@/lib/models/User'
import Client from '@/lib/models/Client'
import CorporateProfile from '@/lib/models/CorporateProfile'
import { loadUserWithProfiles } from '@/lib/user-profiles'
import { requireDomainAccess, requireCompanyCapability, companyCapabilities, companyRoleOf } from '@/lib/domain-access'
import { logAuditEvent } from '@/lib/audit'
import { sanitizeBrandColor, sanitizeNotifyMuted } from '@/lib/company-rights'

export async function GET(request: NextRequest) {
  try {
    const result = await requireDomainAccess(request, 'corporate')
    if (!result.ok) return result.response
    const { access } = result

    await connectDB()

    const companyClientId = access.profiles.companyClientId
    const profileData = await loadUserWithProfiles(access.userId)
    const corporateProfile = profileData?.corporateProfile

    if (!companyClientId) {
      return NextResponse.json({ companyName: null, isEnterprise: false })
    }

    const company = await Client.findById(new mongoose.Types.ObjectId(companyClientId))
      .select('name company email phone address city country contactPerson notes logo brandColor preferences permissions')
      .lean() as any

    const dbUser = profileData?.user || (await User.findById(access.userId)
      .select('name email phone companyClientId companyRole')
      .lean() as any)
    const prefsUser = await User.findById(access.userId).select('portalNotifyMuted').lean() as any

    return NextResponse.json({
      isEnterprise: true,
      userId: access.userId,
      notifyMuted: sanitizeNotifyMuted(prefsUser?.portalNotifyMuted),
      userName: dbUser?.name || access.email,
      userEmail: dbUser?.email || access.email,
      userPhone: dbUser?.phone || null,
      companyClientId,
      companyName: company?.company || company?.name || corporateProfile?.company || 'Votre entreprise',
      companyEmail: company?.email || null,
      companyPhone: company?.phone || null,
      companyAddress: company?.address || corporateProfile?.address || null,
      companyCity: company?.city || corporateProfile?.city || null,
      companyCountry: company?.country || corporateProfile?.country || 'Sénégal',
      companyContactPerson: company?.contactPerson || null,
      companyNotes: company?.notes || null,
      companyLogo: company?.logo || null,
      companyRole: companyRoleOf(access),
      capabilities: Array.from(companyCapabilities(access)),
      companyBrandColor: company?.brandColor || null,
      preferences: company?.preferences || { emailNotifications: true, smsNotifications: false, reportFormat: 'web', language: 'fr' },
      permissions: company?.permissions || { canViewReports: true, canRequestMaintenance: true, canAccessPortal: true },
    })
  } catch (error) {
    console.error('[/api/client-enterprise/me] GET', error)
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const result = await requireDomainAccess(request, 'corporate')
    if (!result.ok) return result.response
    const { access } = result

    const body = await request.json()
    await connectDB()

    const userId = access.userId
    const companyClientId = access.profiles.companyClientId
    const profileData = await loadUserWithProfiles(userId)
    const corporateProfile = profileData?.corporateProfile

    // Champs « société » : réservés owner/admin. Les champs personnels (nom,
    // téléphone) restent modifiables par tout membre pour son propre compte.
    const COMPANY_FIELDS = [
      'companyName', 'companyEmail', 'companyPhone', 'companyAddress', 'companyCity',
      'companyCountry', 'companyContactPerson', 'companyNotes', 'companyLogo', 'companyBrandColor', 'preferences',
    ]
    const touchesCompany = COMPANY_FIELDS.some(f => body[f] !== undefined)
    if (touchesCompany) {
      const denied = requireCompanyCapability(access, 'company:manage')
      if (denied) return denied
    }

    const userUpdates: any = {}
    const userUnsets: Record<string, 1> = {}
    const auditFields: string[] = []
    if (body.userName !== undefined && body.userName !== null) { userUpdates.name = body.userName; auditFields.push('name') }
    if (body.userPhone !== undefined) {
      if (body.userPhone) userUpdates.phone = body.userPhone
      else userUnsets.phone = 1
      auditFields.push('phone')
    }
    if (body.notifyMuted !== undefined) {
      userUpdates.portalNotifyMuted = sanitizeNotifyMuted(body.notifyMuted)
      auditFields.push('notifyMuted')
    }
    if (Object.keys(userUpdates).length > 0 || Object.keys(userUnsets).length > 0) {
      const update: any = {}
      if (Object.keys(userUpdates).length > 0) update.$set = userUpdates
      if (Object.keys(userUnsets).length > 0) update.$unset = userUnsets
      await User.findByIdAndUpdate(userId, update, { new: true })
    }

    // Mise à jour entreprise
    if (companyClientId) {
      const companyUpdates: any = {}
      if (body.companyName !== undefined) companyUpdates.company = body.companyName
      if (body.companyEmail !== undefined) companyUpdates.email = body.companyEmail
      if (body.companyPhone !== undefined) companyUpdates.phone = body.companyPhone
      if (body.companyAddress !== undefined) companyUpdates.address = body.companyAddress
      if (body.companyCity !== undefined) companyUpdates.city = body.companyCity
      if (body.companyCountry !== undefined) companyUpdates.country = body.companyCountry
      if (body.companyContactPerson !== undefined) companyUpdates.contactPerson = body.companyContactPerson
      if (body.companyNotes !== undefined) companyUpdates.notes = body.companyNotes
      if (body.preferences && typeof body.preferences === 'object') {
        const p = body.preferences
        companyUpdates.preferences = {
          emailNotifications: p.emailNotifications !== false,
          smsNotifications: p.smsNotifications === true,
          reportFormat: p.reportFormat === 'pdf' ? 'pdf' : 'web',
          language: p.language === 'en' ? 'en' : 'fr',
        }
      }

      // Logo : n'accepter que des chemins d'upload locaux
      const companyUnsets: Record<string, 1> = {}
      if (body.companyLogo !== undefined) {
        if (typeof body.companyLogo === 'string' && /^\/(api\/)?uploads\//.test(body.companyLogo)) {
          companyUpdates.logo = body.companyLogo
        } else if (body.companyLogo === null || body.companyLogo === '') {
          companyUnsets.logo = 1
        }
      }

      // Couleur de l'espace : hex #RRGGBB uniquement (injectée en variables CSS)
      if (body.companyBrandColor !== undefined) {
        const color = sanitizeBrandColor(body.companyBrandColor)
        if (color) companyUpdates.brandColor = color
        else if (body.companyBrandColor === null || body.companyBrandColor === '') companyUnsets.brandColor = 1
        else return NextResponse.json({ error: 'Couleur invalide' }, { status: 400 })
      }

      // Ne jamais ecrire de null (validator $jsonSchema eventuel)
      for (const k of Object.keys(companyUpdates)) {
        if (companyUpdates[k] === null) delete companyUpdates[k]
      }

      if (Object.keys(companyUpdates).length > 0 || Object.keys(companyUnsets).length > 0) {
        auditFields.push(...Object.keys(companyUpdates).map(k => `company.${k}`), ...Object.keys(companyUnsets).map(k => `company.${k}`))
        const update: any = {}
        if (Object.keys(companyUpdates).length > 0) update.$set = companyUpdates
        if (Object.keys(companyUnsets).length > 0) update.$unset = companyUnsets
        await Client.findByIdAndUpdate(new mongoose.Types.ObjectId(companyClientId), update, { new: true })
      }
    }

    // Mise à jour du profil corporate découplé
    const corporateUpdates: any = {}
    if (body.companyName) corporateUpdates.company = body.companyName
    if (body.companyAddress) corporateUpdates.address = body.companyAddress
    if (body.companyCity) corporateUpdates.city = body.companyCity
    if (body.companyCountry) corporateUpdates.country = body.companyCountry
    if (companyClientId && corporateProfile && !corporateProfile.companyClientId) {
      corporateUpdates.companyClientId = new mongoose.Types.ObjectId(companyClientId)
    }
    if (Object.keys(corporateUpdates).length > 0) {
      await CorporateProfile.findOneAndUpdate(
        { userId: new mongoose.Types.ObjectId(userId) },
        { $set: corporateUpdates },
        { new: true, upsert: true }
      )
    }

    if (auditFields.length > 0) {
      void logAuditEvent({
        entityType: 'Client',
        entityId: companyClientId || userId,
        action: 'profile_updated',
        userId,
        userRole: 'CLIENT',
        clientCompanyId: companyClientId,
        changedFields: auditFields,
      })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('[/api/client-enterprise/me] PUT', error)
    return NextResponse.json({ error: 'Erreur serveur' }, { status: 500 })
  }
}
